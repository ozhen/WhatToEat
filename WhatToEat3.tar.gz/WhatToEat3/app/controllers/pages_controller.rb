class PagesController < ApplicationController
  def weather
  end

  def create
  end
end
