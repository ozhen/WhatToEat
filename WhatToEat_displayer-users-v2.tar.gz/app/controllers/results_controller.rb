class ResultsController < ApplicationController
  def suggestion
  end
end
