class StaticPagesController < ApplicationController
  def homepage
  end
end
