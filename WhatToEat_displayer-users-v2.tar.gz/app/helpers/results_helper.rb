module ResultsHelper
end
